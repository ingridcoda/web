package avaliacao.ano2018.semestre1.trab4;
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
@WebServlet(
		description = "Retorna um hash em formato XML",
		urlPatterns = {
				"/servlet/Leste"
		})

public class Leste extends HttpServlet {
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException,
	IOException {
		long hash = (System.currentTimeMillis() / 10000) % 8752;
		try {
			Thread.sleep((long) (15000 + Math.random() * 20000));
		}
		catch (InterruptedException e) {
			System.err.println("[Servlet Leste] Erro 8752 em sleep");
			return;
		}
		try {
			if(!(request.getParameter("usuario").equals("eu") &&
					request.getParameter("senha").equals("!@#$%*()_+=")))

				return;
		}
		catch(Exception e) {
			return;
		}
		PrintWriter out = response.getWriter();
		response.setContentType("text/xml");
		out.print("<?xml version=\"1.0\"?>");
		out.print("<hash><valor>" + hash + "</valor></hash>");
	}
}