package avaliacao.ano2018.semestre1.trab4;
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import net.sf.json.JSONObject;
@WebServlet(
		description = "Retorna um hash em formato JSON",
		urlPatterns = {
				"/servlet/Oeste"
		})
public class Oeste extends HttpServlet {
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException,
	IOException {
		long hash = (System.currentTimeMillis() / 10000) % 8752;
		try {
			Thread.sleep((long) (15000 + Math.random() * 20000));
		}
		catch (InterruptedException e) {
			System.err.println("[Servlet Velocidade] Erro 8752 em sleep");
			return;
		}
		try {
			if(!(request.getParameter("usuario").equals("eu") &&
					request.getParameter("senha").equals("!@#$%*()_+="))) {

				return;
			}
		}
		catch(Exception e) {
			return;
		}
		PrintWriter out = response.getWriter();
		response.setContentType("text/plain");

		JSONObject hashJSON = new JSONObject();
		hashJSON.put("hash", hash);
		out.print(hashJSON);
	}
}