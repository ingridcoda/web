/*
 * Quarto Trabalho de Programação para a Web
 * Ingrid O. Coda S. Gomes - 1512972
 */

onload = () => {
	document.getElementById('login').addEventListener('click', execute);
	time = '';
	eastHash = 0;
	westHash = 0;
	statusEast = false;
	statusWest = false;
};

function execute(){
	/* 
	 * PROFESSOR, AQUI ALTEREI (COM SUA PERMISSÃO DADA EM SALA NA HORA DA PROVA) O TEMPO
	 * PARA 40 SEGUNDOS, POIS 10 NÃO ERAM SUFICIENTES PARA OBTER AS RESPOSTAS DOS SERVLETS.
	 */ 
	setInterval(() => {
		getDate();
		getWestHash();
		getEastHash();
	}, 40000);
}

function getDate(){
	var datetime = new Date();
	time = "Hora: " + datetime.getHours() + ":" + datetime.getMinutes() + ":" + datetime.getSeconds();
}

function getWestHash(){	
	var username = document.form.username.value;
	var password = encodeURIComponent(document.form.password.value);
	var queryString = "usuario=" + username +"&senha=" + password;
	var request = new XMLHttpRequest();
	request.open("POST", "servlet/Oeste", true);
	request.onreadystatechange = () => {
		if(request.readyState == 4) if(request.status == 200){
			var data = JSON.parse(request.responseText);
			statusWest = true;
			westHash = data.hash;
			authorize();			
		} else {
			removeData('westHash');
			document.getElementById('westHash').appendChild(document.createTextNode("Error #" + request.status));
		}	
	}
	request.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
	request.send(queryString);	
}

function getEastHash(){	
	var username = document.form.username.value;
	var password = encodeURIComponent(document.form.password.value);
	var queryString = "usuario=" + username +"&senha=" + password;
	var request = new XMLHttpRequest();
	request.open("GET", "servlet/Leste?" + queryString, true);
	request.onreadystatechange = () => {
		if(request.readyState == 4) if(request.status == 200){
			var data = request.responseXML.documentElement;
			eastHash = data.getElementsByTagName('valor')[0].firstChild.nodeValue;
			statusEast = true;
			authorize();			
		} else {
			removeData('eastHash');
			document.getElementById('eastHash').appendChild(document.createTextNode("Error #" + request.status));
		}
	}
	request.send(null);	
}

function authorize(){
	removeData('time');
	removeData('westHash');
	removeData('eastHash');
	removeData('authorize');
	if((statusEast && statusWest) && (eastHash == westHash)){
		document.getElementById('time').appendChild(document.createTextNode(time));
		document.getElementById('westHash').appendChild(document.createTextNode("Hash Oeste: " + westHash));
		document.getElementById('eastHash').appendChild(document.createTextNode("Hash Leste: " + eastHash));
		document.getElementById('authorize').appendChild(document.createTextNode("Lançamento autorizado!"));
	}
}

function removeData(id){
	if(document.getElementById(id).hasChildNodes()){
		document.getElementById(id).removeChild(document.getElementById(id).firstChild);
	}
}