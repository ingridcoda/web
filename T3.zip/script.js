function addChild(e) {
    e.preventDefault();
    const parent = e.target.parentNode;
    parent.appendChild(createChild());
}

function createChild() {
    const input = document.createElement('input');
    input.type = 'text';
    input.addEventListener("blur", checkName);

    const button = document.createElement('button');
    button.innerHTML = '+';
    button.onclick = addChild;

    const div = document.createElement('div');
    div.appendChild(input);
    div.appendChild(button);

    return div;
}

function checkName(input) {
    console.log("Confere nome reticulano");
    var texto = input.target.value;
    console.log("Nome: " + texto);

    var regexp = /^[aeiou][aeiouAEIOU]*[aeiou]([^aeiouAEIOU]*[aeiou][aeiouAEIOU]*[aeiou])+$/;
    var resultado = regexp.test(texto);
    console.log("Nome valido: " + resultado);

    return resultado;
}
